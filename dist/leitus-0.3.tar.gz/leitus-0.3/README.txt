Enjoy Leitus, a suite of higher level functions for cryptographic drives.

Leitus is coded in Python for Linux under the GPLv2.

 - Robert Burrell Donkin, 2011
