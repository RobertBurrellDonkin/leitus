Enjoy Leitus, a suite of higher level functions for cryptographic drives.

 - Robert Burrell Donkin, 2011

